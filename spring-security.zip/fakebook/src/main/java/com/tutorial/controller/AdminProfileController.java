package com.tutorial.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tutorial.persistence.model.FakeBookUser;
import com.tutorial.persistence.service.FakeBookUserService;

@RestController
public class AdminProfileController {
	@Autowired
	FakeBookUserService fakeBookUserService;
	
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	@PostMapping("/admin/profile")
	public ResponseEntity<FakeBookUser> findByEmailId() {
		String emailId = ((UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getUsername();
		
		var userDetails = fakeBookUserService.findByEmailId(emailId);
		
		return new ResponseEntity<>(userDetails, HttpStatus.OK);
	}
}
