package com.tutorial.persistence.service;

import com.tutorial.model.AuthResponse;

public interface AuthService {
	AuthResponse findByEmailId(String emailId, String password);
}
