package com.tutorial.persistence.service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;

import com.tutorial.persistence.model.FakeBookUser;

import jakarta.annotation.PostConstruct;

@Service
public class FakeBookUserServiceImpl implements FakeBookUserService {
	private final Map<String, FakeBookUser> FAKE_REPO = new ConcurrentHashMap<String, FakeBookUser>();
	
	/**
	 * FAKE_REPO Mock Data
	 */
	@PostConstruct
	private void init() {
		FakeBookUser userDetails = new FakeBookUser();
		
		userDetails.setEmailId("rajivnh@msn.com");
		userDetails.setPassword("secret");
		userDetails.setRole("ROLE_USER");
		
		FAKE_REPO.put(userDetails.getEmailId(), userDetails);
		
		userDetails = new FakeBookUser();
		
		userDetails.setEmailId("kkadmin@hotmail.com");
		userDetails.setPassword("secret");
		userDetails.setRole("ROLE_ADMIN");
			
		FAKE_REPO.put(userDetails.getEmailId(), userDetails);
	}
	
	@Override
	public FakeBookUser findByEmailId(String emailId) {
		if(!FAKE_REPO.containsKey(emailId)) {
			throw new SecurityException("Email Id Not Found");
		}
		
		return FAKE_REPO.get(emailId);
	}
	
	@Override
	public boolean isValid(String emailId, String password) {
		if(!FAKE_REPO.containsKey(emailId)) {
			throw new SecurityException("Email Id Not Found");
		}
		
		FakeBookUser userDetails = FAKE_REPO.get(emailId);
		
		return userDetails.getPassword().equals(password) ? true : false;
	}
}
