package com.tutorial.persistence.service;

import com.tutorial.persistence.model.FakeBookUser;

public interface FakeBookUserService {
	boolean isValid(String emailId, String password);
	
	FakeBookUser findByEmailId(String emailId);
}
